Name: Shikhar Mohan
Roll No.: 18EC10054
Date: 9/11/2021

Run main.py using Python 3. Code has been tested on
Python - 3.9.5,
numpy - 1.21.2,
matplotlib - 3.4.3
pillow (PIL) - 8.3.2

The command line argument is:
$ python3 main.py

OR

$ python3 main.py -inf folder1/ -outf folder2/

Here folder1 is the name of input folder where extra images reside
And folder2 is the name of output folder where all figures are exported to.

Default value for folder1 is 'images/' and for folder2 is 'output/'.
If folder2 does not exist in the current directory, it will be created.
